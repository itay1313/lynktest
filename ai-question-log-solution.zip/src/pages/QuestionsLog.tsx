import { useState, useMemo } from 'react'
import { useNavigate } from 'react-router-dom'
import { Table, TableColumn, Input, Button, Card } from '../design-system'
import { Question, SortOrder, FilterOptions } from '../types'
import { mockQuestions } from '../data/mockData'

const QuestionsLog = () => {
  const navigate = useNavigate()
  const [sortOrder, setSortOrder] = useState<SortOrder>('desc')
  const [filterOptions, setFilterOptions] = useState<FilterOptions>({})
  const [searchQuery, setSearchQuery] = useState('')

  const formatDate = (dateString: string) => {
    const date = new Date(dateString)
    return date.toLocaleString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    })
  }

  const formatResponseTime = (ms: number) => {
    if (ms < 1000) {
      return `${ms}ms`
    }
    return `${(ms / 1000).toFixed(2)}s`
  }

  const truncateText = (text: string, maxLength: number = 80) => {
    if (text.length <= maxLength) return text
    return text.substring(0, maxLength) + '...'
  }

  const filteredAndSortedQuestions = useMemo(() => {
    let filtered = [...mockQuestions]

    // Filter by date range
    if (filterOptions.startDate) {
      filtered = filtered.filter(
        (q) => new Date(q.timestamp) >= new Date(filterOptions.startDate!)
      )
    }
    if (filterOptions.endDate) {
      filtered = filtered.filter(
        (q) => new Date(q.timestamp) <= new Date(filterOptions.endDate!)
      )
    }

    // Filter by search query
    if (searchQuery) {
      const query = searchQuery.toLowerCase()
      filtered = filtered.filter(
        (q) =>
          q.questionText.toLowerCase().includes(query) ||
          q.userName.toLowerCase().includes(query) ||
          q.fullResponse.toLowerCase().includes(query)
      )
    }

    // Sort by timestamp
    filtered.sort((a, b) => {
      const dateA = new Date(a.timestamp).getTime()
      const dateB = new Date(b.timestamp).getTime()
      return sortOrder === 'asc' ? dateA - dateB : dateB - dateA
    })

    return filtered
  }, [filterOptions, sortOrder, searchQuery])

  const columns: TableColumn<Question>[] = [
    {
      key: 'questionText',
      header: 'Question',
      render: (question) => (
        <div className="max-w-md">
          <p className="text-gray-900 font-medium">
            {truncateText(question.questionText)}
          </p>
        </div>
      )
    },
    {
      key: 'timestamp',
      header: 'Timestamp',
      render: (question) => (
        <span className="text-gray-600">{formatDate(question.timestamp)}</span>
      )
    },
    {
      key: 'responseTime',
      header: 'Response Time',
      render: (question) => (
        <span className="text-gray-700 font-mono">
          {formatResponseTime(question.responseTime)}
        </span>
      )
    },
    {
      key: 'userName',
      header: 'User',
      render: (question) => (
        <span className="text-gray-700">{question.userName}</span>
      )
    }
  ]

  const handleRowClick = (question: Question) => {
    navigate(`/question/${question.id}`)
  }

  const handleSortToggle = () => {
    setSortOrder(sortOrder === 'asc' ? 'desc' : 'asc')
  }

  const handleStartDateChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setFilterOptions({
      ...filterOptions,
      startDate: e.target.value || undefined
    })
  }

  const handleEndDateChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setFilterOptions({
      ...filterOptions,
      endDate: e.target.value || undefined
    })
  }

  const clearFilters = () => {
    setFilterOptions({})
    setSearchQuery('')
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-8">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">
            AI Question Log
          </h1>
          <p className="text-gray-600">
            View and manage all questions asked to the AI system
          </p>
        </div>

        <Card className="mb-6">
          <div className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
              <div className="md:col-span-2">
                <Input
                  type="text"
                  placeholder="Search questions, users, or responses..."
                  value={searchQuery}
                  onChange={(e) => setSearchQuery(e.target.value)}
                />
              </div>
              <Input
                type="date"
                label="Start Date"
                value={filterOptions.startDate || ''}
                onChange={handleStartDateChange}
              />
              <Input
                type="date"
                label="End Date"
                value={filterOptions.endDate || ''}
                onChange={handleEndDateChange}
              />
            </div>
            <div className="flex items-center gap-4">
              <Button
                variant="outline"
                size="sm"
                onClick={handleSortToggle}
              >
                Sort: {sortOrder === 'asc' ? 'Oldest First' : 'Newest First'}
              </Button>
              {(filterOptions.startDate || filterOptions.endDate || searchQuery) && (
                <Button
                  variant="secondary"
                  size="sm"
                  onClick={clearFilters}
                >
                  Clear Filters
                </Button>
              )}
              <div className="ml-auto text-sm text-gray-600">
                Showing {filteredAndSortedQuestions.length} of {mockQuestions.length} questions
              </div>
            </div>
          </div>
        </Card>

        <Card>
          {filteredAndSortedQuestions.length > 0 ? (
            <Table
              data={filteredAndSortedQuestions}
              columns={columns}
              onRowClick={handleRowClick}
            />
          ) : (
            <div className="text-center py-12">
              <p className="text-gray-500 text-lg">No questions found matching your filters.</p>
            </div>
          )}
        </Card>
      </div>
    </div>
  )
}

export default QuestionsLog

