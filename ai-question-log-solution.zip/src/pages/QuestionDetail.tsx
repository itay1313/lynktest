import { useParams, useNavigate } from 'react-router-dom'
import { Card, Button, Badge } from '../design-system'
import { mockQuestions } from '../data/mockData'

const QuestionDetail = () => {
  const { id } = useParams<{ id: string }>()
  const navigate = useNavigate()
  const question = mockQuestions.find((q) => q.id === id)

  const formatDate = (dateString: string) => {
    const date = new Date(dateString)
    return date.toLocaleString('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit',
      second: '2-digit'
    })
  }

  const formatResponseTime = (ms: number) => {
    if (ms < 1000) {
      return `${ms} milliseconds`
    }
    return `${(ms / 1000).toFixed(2)} seconds`
  }

  const getResponseTimeBadgeVariant = (ms: number) => {
    if (ms < 500) return 'success'
    if (ms < 1000) return 'info'
    if (ms < 2000) return 'warning'
    return 'error'
  }

  if (!question) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <Card className="max-w-md">
          <div className="text-center">
            <h2 className="text-2xl font-bold text-gray-900 mb-4">
              Question Not Found
            </h2>
            <p className="text-gray-600 mb-6">
              The question you're looking for doesn't exist or has been removed.
            </p>
            <Button onClick={() => navigate('/')}>
              Back to Questions Log
            </Button>
          </div>
        </Card>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="mb-6">
          <Button
            variant="outline"
            size="sm"
            onClick={() => navigate('/')}
            className="mb-4"
          >
            ← Back to Questions Log
          </Button>
          <h1 className="text-3xl font-bold text-gray-900">Question Details</h1>
        </div>

        <div className="space-y-6">
          <Card>
            <div className="space-y-6">
              <div>
                <h2 className="text-sm font-medium text-gray-500 uppercase tracking-wide mb-2">
                  Question
                </h2>
                <p className="text-lg text-gray-900">{question.questionText}</p>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6 pt-6 border-t border-gray-200">
                <div>
                  <h3 className="text-sm font-medium text-gray-500 uppercase tracking-wide mb-2">
                    User
                  </h3>
                  <p className="text-base text-gray-900">{question.userName}</p>
                  <p className="text-sm text-gray-500 mt-1">ID: {question.userId}</p>
                </div>

                <div>
                  <h3 className="text-sm font-medium text-gray-500 uppercase tracking-wide mb-2">
                    Timestamp
                  </h3>
                  <p className="text-base text-gray-900">{formatDate(question.timestamp)}</p>
                </div>
              </div>

              <div className="pt-6 border-t border-gray-200">
                <h3 className="text-sm font-medium text-gray-500 uppercase tracking-wide mb-2">
                  Response Time
                </h3>
                <div className="flex items-center gap-2">
                  <Badge variant={getResponseTimeBadgeVariant(question.responseTime)}>
                    {formatResponseTime(question.responseTime)}
                  </Badge>
                </div>
              </div>
            </div>
          </Card>

          <Card>
            <div>
              <h2 className="text-sm font-medium text-gray-500 uppercase tracking-wide mb-4">
                AI Response
              </h2>
              <div className="prose max-w-none">
                <p className="text-base text-gray-900 whitespace-pre-wrap leading-relaxed">
                  {question.fullResponse}
                </p>
              </div>
            </div>
          </Card>
        </div>
      </div>
    </div>
  )
}

export default QuestionDetail

